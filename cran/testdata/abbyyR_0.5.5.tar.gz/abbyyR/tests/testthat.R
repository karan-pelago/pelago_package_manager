library(testthat)
library(abbyyR)

test_check("abbyyR")
